accbaslangic=201
while :
do
cds=0 #kopyalanan dosya sayısı
splotsayisi=0
dplotsayisi=0
splotsayisi=($(rclone ls kaliciyernf: | wc -l))
dplotsayisi=($(rclone ls kaliciyernfcop1: | wc -l))
echo "---------------------------------------------------------"
echo -e "\e[3;36m Source Plot Sayisi: $splotsayisi \e[0m"
echo "---------------------------------------------------------"
echo -e "\e[3;36m Destin Plot Sayisi: $dplotsayisi \e[0m"
echo "---------------------------------------------------------"
if [[ $splotsayisi -gt $(($dplotsayisi - 1)) ]]; then
cds=$(($cds + 1))
fi
if [[ $splotsayisi -gt -1 ]]; then
cds=$cds
if [[ $splotsayisi -gt $(($dplotsayisi - 1)) ]]; then
cds=0
fi
echo -e "\e[3;32m $cds . Plot Transferi Baslatiliyor ... \e[0m"
rclone copy kaliciyernf: kaliciyernfcop1: --drive-service-account-file=/root/karsliyedekalma/300/$accbaslangic.json  --include "/*.plot" --multi-thread-streams 10 -P --max-transfer=730G --drive-stop-on-upload-limit --drive-server-side-across-configs -v  --fast-list --ignore-existing
sleep 1
accbaslangic=$(($accbaslangic + 1));
echo Secilen Service Account....: $accbaslangic
fi
if [[ $dplotsayisi -gt $(($splotsayisi - 1)) ]]; then
break
fi
sleep 1
done
